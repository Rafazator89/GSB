<?php

namespace Pg\GsbFraisBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PgGsbFraisBundle extends Bundle
{
}
